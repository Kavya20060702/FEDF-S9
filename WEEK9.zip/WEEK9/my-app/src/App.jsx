import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import BookList from "./BookList";
import BookDetail from "./BookDetail";

function App() {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    const data = [
      { id: 1, title: "Harry Potter", author: "J.K. Rowling", description: "Magic story", rating: 4.8 },
      { id: 2, title: "The Hobbit", author: "Tolkien", description: "Adventure story", rating: 4.7 }
    ];
    setBooks(data);
  }, []);

  return (
    <Router>
      <Routes>
        <Route path="/" element={<BookList books={books} />} />
        <Route path="/book/:id" element={<BookDetail books={books} />} />
      </Routes>
    </Router>
  );
}

export default App;
