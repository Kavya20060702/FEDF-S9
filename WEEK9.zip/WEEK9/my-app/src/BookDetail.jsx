import React from "react";
import { useParams, Link } from "react-router-dom";

function BookDetail({ books }) {
  const { id } = useParams();
  const book = books.find(b => b.id === parseInt(id));

  if (!book) return <p>Book not found</p>;

  return (
    <div>
      <h1>{book.title}</h1>
      <p>Author: {book.author}</p>
      <p>Description: {book.description}</p>
      <p>Rating: {book.rating}</p>
      <Link to="/"><button>Back</button></Link>
    </div>
  );
}

export default BookDetail;
