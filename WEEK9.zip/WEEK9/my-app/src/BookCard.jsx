import React from "react";
import { Link } from "react-router-dom";

function BookCard({ book }) {
  return (
    <div>
      <h2>{book.title}</h2>
      <p>{book.author}</p>
      <Link to={`/book/${book.id}`}><button>View Details</button></Link>
    </div>
  );
}

export default BookCard;
